# tests/__init__.py

"""
Suite de tests para el bot de Baccarat.
"""
